package vetores;

import java.util.Scanner;

public class Exercicio3 {

    public static void main(String[] args) {

        String[] nomes = new String[10];
        Scanner leitorLn = new Scanner(System.in);
        Scanner leitor = new Scanner(System.in);

        for (int i = 0; i < nomes.length ; i++) {
            System.out.println("Digite um nome");
            nomes[i] = leitorLn.nextLine();
        }

        System.out.println(nomes.length);
        Boolean encontrado = false;
        System.out.println("Pesquise por um nome");
        String nomePesquisa = leitor.nextLine();
        for (int i = 0; i < nomes.length ; i++) {
            if (nomes[i].contains(nomePesquisa)){
                System.out.println("Nome encontrado no índice " + i);
                encontrado = true;
                break;
            }
        }

        if (!encontrado){
            System.out.println("Nome não encontrado");
        }
    }
}