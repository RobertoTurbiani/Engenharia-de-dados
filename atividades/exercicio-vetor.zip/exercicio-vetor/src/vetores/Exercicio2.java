package vetores;

import java.util.Scanner;

public class Exercicio2 {

    public static void main(String[] args) {

        int vetor[] = new int[10];

        Scanner leitorLn = new Scanner(System.in);
        Integer total = 0;

        for (int i = 0; i < vetor.length ; i++) {

            System.out.println("Preencha o número [" +  i + "]:");
            vetor[i] = leitorLn.nextInt();
            total += vetor[i];
        }

        double media = (double) total  / vetor.length;
        System.out.println("Média " + media );

        for (int i = 0; i < vetor.length ; i++) {
            if (vetor[i] > media){
                System.out.println(vetor[i]);
            }
        }
        
    }
}
