package vetores;

import java.util.Scanner;

public class Exercicio4 {

    public static void main(String[] args) {
        int[] numeros = new int[10];
        Scanner leitorLn = new Scanner(System.in);


        System.out.println("Digite 10 números inteiros");

        for (int i = 0; i <numeros.length ; i++) {
            Integer numerosDigitados = leitorLn.nextInt();
            numeros[i] = numerosDigitados;
        }

        System.out.println("Digite um número");
        Integer numeroPesquisa = leitorLn.nextInt();
        Integer qtd = 0;
        for (int i = 0; i <numeros.length ; i++) {
            if (numeros[i] == numeroPesquisa){
                qtd ++;
            }
        }

        if (qtd > 0){
            System.out.println("O número " + numeroPesquisa + " ocorreu " + qtd );
        } else {
            System.out.println("O número " + numeroPesquisa + " não ocorre nenhuma vez.");        }
    }

}
