package desafio;

import java.util.concurrent.ThreadLocalRandom;

public class Mapa {


    public static void main(String[] args) {


        String[] mapa = {"Tesouro","Armadilha","Vazio"};

        for (int i = 1; i <=3 ; i++) {
            int posicaoMapa = ThreadLocalRandom.current().nextInt(0, 2)  * mapa.length ;

            if (posicaoMapa<=1){
                System.out.println(mapa[0]);
            } else if (posicaoMapa <= 2) {
                System.out.println(mapa[1]);
            } else {
                System.out.println(mapa[2]);
            }

        }

    }
}
