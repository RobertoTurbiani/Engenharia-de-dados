import java.util.List;

public class ControleAlunos {

    List<Aluno> alunos;
    FilaObj<Aluno> alunosMatricular;
    PilhaObj<Integer> pilhaDesfazer;
    PilhaObj<Integer> pilhaRefazer;

    private String[] categoriaAlunos;
    private double[] mediaColuna;
    private double[] mediaLinha;
    private double[][] matrizRelatorio;

    public void matricular(Aluno aluno){
        alunos.add(aluno);
    }
    public void agendarMatricula(Aluno aluno){
        alunosMatricular.insert(aluno);
    }
    public void executarAgendamentos(int qtd){
        while (qtd >= 0) {
           matricular(alunosMatricular.poll());
            qtd --;
        }
    }

    public void somarPontos(int pontosSomar){

        for (int i = 0; i <alunos.size(); i++) {
        alunos.get(i).setNotaFinal(alunos.get(i).getNotaFinal() + pontosSomar);
        }
        pilhaDesfazer.push(pontosSomar);
    }

    public void tirarPontos(int pontosTirar){
        for (int i = 0; i <alunos.size() ; i++) {
            alunos.get(i).setNotaFinal(alunos.get(i).getNotaFinal() - pontosTirar);
        }
    }
    public void desfazerSomarPontos(){
        if (!pilhaDesfazer.isEmpty()) {
            if (!pilhaRefazer.isFull()) {
                pilhaRefazer.push(pilhaDesfazer.peek());
                tirarPontos(pilhaDesfazer.pop());
            }
        }
    }
    public void refazerSomarPontos(){
        if (!pilhaRefazer.isEmpty()) {
            somarPontos(pilhaRefazer.pop());
        }
    }

    public void calculaCapacidaDaMatriz(){

        matrizRelatorio = new double [categoriaAlunos.length][3];
    }

    public void vetorDeItensDaFila(int qtd){

        int vetor[] = new int[qtd];

        for (int i = 0; i < vetor.length; i++) {
            vetor[i] = alunosMatricular.poll().getNotaFinal().intValue();
        }
    }

    public void exibirRelatorio() {
        for (int i = 0; i < matrizRelatorio.length; i++) {
            double sum = 0;
            for (int j = 0; j < matrizRelatorio[i].length; j++) {
                sum += matrizRelatorio[i][j];
            }
            mediaLinha[i] = sum / matrizRelatorio[i].length;
        }

        for (int j = 0; j < matrizRelatorio[0].length; j++) {
            double sum = 0;
            for (int i = 0; i < matrizRelatorio.length; i++) {
                sum += matrizRelatorio[i][j];
            }
            mediaColuna[j] = sum / matrizRelatorio.length;
        }

        System.out.println("Relatório de Alunos:");
        for (int i = 0; i < categoriaAlunos.length; i++) {
            System.out.println("Categoria: " + categoriaAlunos[i]);
            System.out.println("Média: " + mediaLinha[i]);
            System.out.println("Jan: " + matrizRelatorio[i][0] + ", Fev: " + matrizRelatorio[i][1] + ", Mar: " + matrizRelatorio[i][2]);
        }

        System.out.println("Média de alunos matriculados em Jan: " + mediaColuna[0]);
        System.out.println("Média de alunos matriculados em Fev: " + mediaColuna[1]);
        System.out.println("Média de alunos matriculados em Mar: " + mediaColuna[2]);
    }

}
