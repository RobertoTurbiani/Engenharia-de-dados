public class PilhaObj<T> {
    private T[] pilhaObj;
    private int topo;

    public PilhaObj(int capacidade) {
        this.pilhaObj = (T[]) new Object[capacidade];
        this.topo = - 1;
    }

    public boolean isEmpty(){
        return topo == -1;
    }

    public boolean isFull(){
        return topo == pilhaObj.length - 1;
    }

    public void push(T info){

        if (isFull()){
            return;
        }

        pilhaObj[++topo] = info;
    }

    public T pop(){
        if (isEmpty()){
            return null;
        }

        return pilhaObj[topo--];
    }

    public T peek(){
        if (isEmpty()){
            return null;
        }

        return pilhaObj[topo];
    }

    public void exibe(){
        if (isEmpty()){
            System.out.println("Pilha vazia");
        }

        for (int i = topo; i >= 0; i--) {
            System.out.print(pilhaObj[i] + " ");
        }
    }
}