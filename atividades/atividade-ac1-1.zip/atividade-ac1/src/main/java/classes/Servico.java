package classes;

public class Servico  implements IServico {

    String tipoPLano;
    Double valorPlano;
    @Override
    public Double valorServico() {

        if (tipoPLano.equals("Plano Simples")){
            valorPlano = 18.90;
        } else if (tipoPLano.equals("Plano Médio")) {
            valorPlano = 28.90;
        } else if (tipoPLano.equals("Plano Completo")) {
            valorPlano = 45.90;
        }
        return valorPlano;
    }
}
