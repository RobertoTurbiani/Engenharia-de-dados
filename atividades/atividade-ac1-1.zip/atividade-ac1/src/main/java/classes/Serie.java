package classes;

public abstract class Serie{

   private String titulo;
   private Integer qtdEpisodio;

    public Serie(String titulo, Integer qtdEpisodio) {
        this.titulo = titulo;
        this.qtdEpisodio = qtdEpisodio;

    }


    public abstract void selecionarReproducao(String nomeSerie);
    public abstract void iniciarReproducao();
    public abstract void exibirCatalogo();
    public abstract void trocarEpisodio();


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Integer getQtdEpisodio() {
        return qtdEpisodio;
    }

    public void setQtdEpisodio(Integer qtdEpisodio) {
        this.qtdEpisodio = qtdEpisodio;
    }

}


