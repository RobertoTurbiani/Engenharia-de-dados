package classes;

public class TesteSerie {

    public static void main(String[] args) {

        Streaming serie01 = new Streaming ("",0,0.0,"","");

        serie01.exibirCatalogo();

        serie01.selecionarReproducao("Vikings");

        serie01.iniciarReproducao();

        serie01.trocarEpisodio();
        serie01.trocarEpisodio();




    }
}
