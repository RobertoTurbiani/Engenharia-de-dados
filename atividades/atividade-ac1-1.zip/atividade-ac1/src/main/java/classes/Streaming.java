package classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class Streaming extends Serie {

    private List<String> listaSerie = new ArrayList<>(List.of("Game of Thrones", "Vikings", "Supernatural"));
    private List<Integer> listaepisodio = new ArrayList<>(List.of(60, 50, 180));
    private String serieSelecionada;
    private Integer episodioAtual;


    public Streaming(String titulo, Integer qtdEpisodio, Double mediaDuracaoEp, String sinopse, String genero) {
        super(titulo, qtdEpisodio);
        this.episodioAtual = 1;

    }

    @Override
    public void selecionarReproducao(String nomeSerie ) {

        if (listaSerie.contains(nomeSerie)){
            System.out.println("série: " + nomeSerie + " Escolhida");
            serieSelecionada = nomeSerie;
        } else {
            System.out.println("A série '" + nomeSerie + "' não está no nosso catálogo.");

        }
    }

    @Override
    public void iniciarReproducao() {

        if (serieSelecionada != null){
        System.out.println("Iniciando a Reprodução da série: " + serieSelecionada + " aguarde um momento...");
        } else {
            System.out.println("Escolha uma série para comerçarmos");
        }
    }



    @Override
    public void exibirCatalogo() {

        for (int i = 0; i <listaSerie.size() && i < listaepisodio.size() ; i++) {
            System.out.println("série: " + listaSerie.get(i) + ", Total de episódio: " + listaepisodio.get(i));

        }

    }

    @Override
    public void trocarEpisodio() {

        if (listaSerie != null) {
            System.out.println("Episódio atual:" + episodioAtual);
            for (int i = 0; i <1; i++) {
            if (episodioAtual < listaepisodio.size()) {

                episodioAtual ++;
                System.out.println("Iniciando o próximo episódio:" + episodioAtual);
            }
            }
        }
    }

}
