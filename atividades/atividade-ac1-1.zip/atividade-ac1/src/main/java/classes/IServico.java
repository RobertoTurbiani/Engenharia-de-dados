package classes;

public interface IServico {

   Double valorServico();


}
