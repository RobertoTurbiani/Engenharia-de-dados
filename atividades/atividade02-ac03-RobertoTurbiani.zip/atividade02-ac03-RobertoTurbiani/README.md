[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/dm--2JwJ)
# Atividade 03 - Avaliação Continuada 03 📎

### Relacionado ao seu tema (mesmo tema das atividades anteriores):
- ✅ Crie um vetor de Strings de tamanho no mínimo 6 e preencha os valores desse vetor
  - (pode ser de nome de time, ou de jogador, por exemplo, se o tema for Futebol).
  - Pode preencher os valores de forma fixa mesmo, não precisa utilizar Scanner.
- ✅ Crie uma matriz de int ou Integer, ou de double ou Double
  	- A quantidade de linhas será o tamanho do vetor de Strings, e 2 colunas. (por exemplo, no caso do tema Futebol, a 1ª coluna pode ser a pontuação de cada time ou jogador no ano passado, e a 2ª coluna a pontuação de cada time ou jogador neste ano).
  	- Preencha também os valores desta matriz, podendo ser de forma fixa no código, não precisa utilizar Scanner.
- ✅ Crie um vetor de tamanho 2, de tipo double ou Double, que conterá a soma ou média de cada coluna da matriz.
  - Calcule os valores e preencha esse vetor.
- ✅ Crie um vetor de tamanho igual ao vetor de Strings, de tipo double, ou Double, que conterá a soma ou média de cada linha da matriz.
  - Calcule os valores e preencha esse vetor.
    
### 🗒️ No final, exiba um relatório, com os títulos das colunas, utilizando a saída formatada, como no exercício 6 da lista de exercícios da matriz.



