package school.sptech;

import java.util.concurrent.ThreadLocalRandom;

public class Main {


  public static void main(String[] args) {

    String[] filme = new String[6];

    filme[0] = "Titanic";
    filme[1] = "Avatar";
    filme[2] = "Vingadores";
    filme[3] = "Harry Potter";
    filme[4] = "Batman";
    filme[5] = "Homem Aranha";

    double[][] nota = new double[filme.length][2];


    for (int i = 0; i < filme.length; i++) {
      nota[i][0] = ThreadLocalRandom.current().nextDouble(5, 10);
      nota[i][1] = ThreadLocalRandom.current().nextDouble(5, 10);
    }

    double[] media = new double[2];

    for (int i = 0; i < filme.length; i++) {
      media[0] += nota[i][0];
      media[1] += nota[i][1];
    }

    media[0] /= filme.length;
    media[1] /= filme.length;

    double[] mediaTotal = new double[filme.length];

    for (int i = 0; i < filme.length; i++) {
      double soma = 0;
      for (int j = 0; j < 2; j++) {
        soma += nota[i][j];
      }
      mediaTotal[i] = soma / 2;
    }


    System.out.printf("%-20s %-20s %-20s %-20s%n", "Nome", "Nota Ano Passado", "Nota Ano Atual", "Nota Média");
    for (int i = 0; i < filme.length; i++) {
      System.out.printf("%-20s %-20.2f %-20.2f %-20.2f%n", filme[i], nota[i][0], nota[i][1], mediaTotal[i]);
    }

    System.out.printf("%-20s %-20.2f %-20.2f%n","Média", media[0], media[1]);
  }
}