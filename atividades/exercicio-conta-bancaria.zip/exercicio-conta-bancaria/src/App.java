import java.util.Scanner;

public class App {
    public static void main(String[] args) {

     PilhaObj pilhaObj = new PilhaObj<>(10);
     FilaObj filaObj = new FilaObj<>(10);
     Integer contador = 0;


     ContaBancaria contaBancaria01 = new ContaBancaria(21,500.);
     ContaBancaria contaBancaria02 = new ContaBancaria(41,800.);

     Scanner leitorNum = new Scanner(System.in);
     Scanner leitorText = new Scanner(System.in);
     int opcao;


        do {
            System.out.println("Escolha uma opção:");
            System.out.println("1- Debitar valor");
            System.out.println("2- Creditar (Depositar) valor");
            System.out.println("3- Desfazer operação");
            System.out.println("4- Agendar operação");
            System.out.println("5- Executar operações agendadas");
            System.out.println("6- Sair");
            opcao = leitorNum.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o número da conta:");
                    Integer numeroConta = leitorNum.nextInt();
                    System.out.println("Digite o valor a ser debitado:");
                    Double valor = leitorNum.nextDouble();

                    ContaBancaria contaSelecionada = null;
                    if (contaBancaria01.getNumero().equals(numeroConta)) {
                        contaSelecionada = contaBancaria01;
                    } else if (contaBancaria02.getNumero().equals(numeroConta)) {
                        contaSelecionada = contaBancaria02;
                    }

                    if (contaSelecionada != null) {
                        if (contaSelecionada.debitar(valor)) {
                            Operacao operacao = new Operacao(contaSelecionada, "debito", valor);
                            try {
                                pilhaObj.push(operacao);
                                contador++;
                            } catch (Exception e) {
                                throw new IllegalStateException();
                            }
                        }
                    } else {
                        System.out.println("Conta não encontrada.");
                    }
                    break;
                case 2:

                    System.out.println("Digite o número da conta:");
                    Integer numeroContaCred = leitorNum.nextInt();
                    System.out.println("Digite o valor a ser creditado:");
                    Double valorCred = leitorNum.nextDouble();

                    ContaBancaria contaSelecionadaCred = null;
                    if (contaBancaria01.getNumero().equals(numeroContaCred)) {
                        contaSelecionada = contaBancaria01;
                    } else if (contaBancaria02.getNumero().equals(numeroContaCred)) {
                        contaSelecionada = contaBancaria02;
                    }

                    if (contaSelecionadaCred != null) {
                        if (contaSelecionadaCred.debitar(valorCred)) {
                            Operacao operacao = new Operacao(contaSelecionadaCred, "credito", valorCred);
                            try {
                                pilhaObj.push(operacao);
                                contador++;
                            } catch (Exception e) {
                                throw new IllegalStateException();
                            }
                        }
                    } else {
                        System.out.println("Conta não encontrada.");
                    }

                    break;
                case 3:
                    System.out.println("Digite quantas ações deseja desfazer");
                    Integer operacoes = leitorNum.nextInt();

                    if (operacoes > contador){
                        System.out.println("Quantidade inválida");
                    } else {
                        for (int i = 0; i < operacoes; i++) {
                            Operacao operacaoDesfazer = (Operacao) pilhaObj.pop();
                            if (operacaoDesfazer != null) {
                                if (operacaoDesfazer.getTipoOperacao().equals("debito")) {
                                    operacaoDesfazer.getContaBancaria().creditar(operacaoDesfazer.getValor());
                                } else if (operacaoDesfazer.getTipoOperacao().equals("credito")) {
                                    operacaoDesfazer.getContaBancaria().debitar(operacaoDesfazer.getValor());
                                }
                                contador--;
                            }
                            }
                    }

                    break;
                case 4:

                    System.out.println("Digite o tipo de operação");
                    String tipoOp = leitorText.nextLine();
                    System.out.println("Digite o número da conta:");
                    Integer numeroCont = leitorNum.nextInt();
                    System.out.println("Digite o valor a ser creditado:");
                    Double valorCont = leitorNum.nextDouble();

                    ContaBancaria contaSelecionadaAtual = null;
                    if (contaBancaria01.getNumero().equals(numeroCont)) {
                        contaSelecionada = contaBancaria01;
                    } else if (contaBancaria02.getNumero().equals(numeroCont)) {
                        contaSelecionada = contaBancaria02;
                    }

                    Operacao operacao = new Operacao(contaSelecionadaAtual,tipoOp, valorCont);

                    try {
                        filaObj.insert(operacao);
                        contador++;
                    } catch (IllegalStateException e){
                        throw new IllegalStateException();
                    }

                    break;
                case 5:
                    if (filaObj.isEmpty()) {
                        System.out.println("Não há operações agendadas.");
                    } else {
                        while (!filaObj.isEmpty()) {
                            Operacao operacaoAgendada = (Operacao) filaObj.poll();
                            if (operacaoAgendada.getTipoOperacao().equals("debito")) {
                                operacaoAgendada.getContaBancaria().debitar(operacaoAgendada.getValor());
                            } else if (operacaoAgendada.getTipoOperacao().equals("credito")) {
                                operacaoAgendada.getContaBancaria().creditar(operacaoAgendada.getValor());
                            }
                        }
                    }
                    break;
                case 6:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 6);
    }
}
