package classes;

import java.util.ArrayList;
import java.util.List;

public class Musica extends  Serie{
    private List<String> listaMusica = new ArrayList<>(List.of("Fear of the Dark", "One"));
    private  List<String> musicasBaixados = new ArrayList<>();
    private String musicaSelecionada;
    private Integer musicaAtual = 1;


    @Override
    public void iniciarReproducao() {

        if (musicaSelecionada != null){
            System.out.println("Iniciando a Reprodução da música: " + musicaSelecionada + " aguarde um momento...");
        } else {
            System.out.println("Escolha uma música para comerçarmos");
        }
    }

    @Override
    public void exibirCatalogo() {

        for (int i = 0; i <listaMusica.size() && i < listaMusica.size() ; i++) {
            System.out.println("Músicas no catálogo: " + listaMusica.get(i) + "\n");

        }

    }

    @Override
    public void selecionarReproducao(String nomeMusica ) {

        if (listaMusica.contains(nomeMusica)){
            System.out.println("Música: " + nomeMusica + " Escolhida");
            musicaSelecionada = nomeMusica;
        } else {
            System.out.println("A série '" + nomeMusica + "' não está no nosso catálogo.");

        }
    }

    @Override
    public void trocarEpisodio() {}

    public void baixarMusica(String nomeMusica){

        for (int i = 1; i < listaMusica.size(); i++) {

            if (musicasBaixados.size() <= 100){
               musicasBaixados.add(nomeMusica);
            } else {
                break;
            }
            System.out.println("Baixando a música %s".formatted(nomeMusica));

        }

    }

    public List<String> getListaMusica() {
        return listaMusica;
    }

    public void setListaMusica(List<String> listaMusica) {
        this.listaMusica = listaMusica;
    }

    public List<String> getMusicasBaixados() {
        return musicasBaixados;
    }

    public void setMusicasBaixados(List<String> musicasBaixados) {
        this.musicasBaixados = musicasBaixados;
    }

    public String getMusicaSelecionada() {
        return musicaSelecionada;
    }

    public void setMusicaSelecionada(String musicaSelecionada) {
        this.musicaSelecionada = musicaSelecionada;
    }
}
