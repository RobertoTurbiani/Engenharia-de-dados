package classes;

import java.util.ArrayList;
import java.util.List;

public class SerieEspecial extends  Serie{
    private List <Integer> serieAlugada = new ArrayList<>();
    private List <String> tituloSerieAlugada = new ArrayList<>();
    private List<String> catalogoSerieParaAlugar = new ArrayList<>(List.of("Loki","Percy Jackson"));
    private List<Integer> qtdEpisodioSerieParaAlugar = new ArrayList<>(List.of(1,2,3,4,5,6,7,8,9,10));

    private String serieSelecionada;
    private Integer episodioAtual = 1;

    @Override
    public void iniciarReproducao() {
        if (serieSelecionada != null){
            System.out.println("Iniciando a Reprodução da série: " + serieSelecionada + " aguarde um momento...");
        } else {
            System.out.println("Escolha uma série para comerçarmos");
        }
    }

    @Override
    public void trocarEpisodio() {
        if (catalogoSerieParaAlugar != null) {
            System.out.println("Episódio atual:" + episodioAtual);
            for (int i = 0; i < 1; i++) {
                if (episodioAtual < catalogoSerieParaAlugar.size()) {

                    episodioAtual ++;
                    System.out.println("Iniciando o próximo episódio, episódio:" + episodioAtual);
                } else {
                    System.out.println("Esse é o ultimo episódio ");
                }
            }
        }
    }

    @Override
    public void exibirCatalogo() {

        for (int i = 0; i <catalogoSerieParaAlugar.size() && i < qtdEpisodioSerieParaAlugar.size() ; i++) {
            System.out.println("séries no Catálogo Especial: " + catalogoSerieParaAlugar.get(i) + "\n");
        }
    }


    @Override
    public void selecionarReproducao(String nomeSerie) {
        if (catalogoSerieParaAlugar.contains(nomeSerie)){
            System.out.println("série: " + nomeSerie + " Escolhida");
            serieSelecionada = nomeSerie;
        } else {
            System.out.println("A série '" + nomeSerie + "' não está no nosso catálogo.");
        }
    }

    public void alugarSerie(String nomeSerie){


        if (catalogoSerieParaAlugar.contains(nomeSerie) && serieAlugada.size() <= 2) {
            for (int i = serieAlugada.size(); i < qtdEpisodioSerieParaAlugar.size() && serieAlugada.size() <2; i++) {
                episodioAtual = i + 1;

                        serieAlugada.add(episodioAtual);
                System.out.println("alugando: %d episódios da série: %s ".formatted(serieAlugada.size(), nomeSerie));

            }

        } else {
            System.out.println("Selecione outra série");
        }
    }
    public List<Integer> getSerieAlugada() {
        return serieAlugada;
    }

    public void setSerieAlugada(List<Integer> serieAlugada) {
        serieAlugada = serieAlugada;
    }

    public List<String> getTituloSerieAlugada() {
        return tituloSerieAlugada;
    }

    public void setTituloSerieAlugada(List<String> tituloSerieAlugada) {
        this.tituloSerieAlugada = tituloSerieAlugada;
    }

}
