package classes;

public class Streaming implements IStreaming {


    private String tipoPLano;
    private Double valorPlano;

    @Override
    public Double tipoServico(String tipoDePlano) {

        if (tipoDePlano.equals("Plano Simples")){
            valorPlano = 18.90;
            System.out.println("Você escolheu o plano: %s por apenas %.2f".formatted(tipoDePlano,valorPlano));
        } else if (tipoDePlano.equals("Plano Médio")) {
            valorPlano = 28.90;
            System.out.println("Você escolheu o plano: %s por apenas %.2f".formatted(tipoDePlano,valorPlano));
        } else if (tipoDePlano.equals("Plano Completo")) {
            valorPlano = 45.90;
            System.out.println("Você escolheu o plano: %s por apenas %.2f".formatted(tipoDePlano,valorPlano));
        }
        return valorPlano;
    }

}
