package classes;

import java.util.ArrayList;
import java.util.List;

public abstract class Serie extends Streaming{

    private List<String>  episodios = new ArrayList<>();
    private List<Integer> qtdEpisodios = new ArrayList<>();

    public Serie() {
        this.episodios = episodios;
        this.qtdEpisodios = qtdEpisodios;
    }

    public abstract void selecionarReproducao(String nomeSerie);
    public abstract void iniciarReproducao();
    public abstract void exibirCatalogo();
    public abstract void trocarEpisodio();

    public List<String> getEpisodios() {
        return episodios;
    }

    public void setEpisodios(List<String> episodios) {
        this.episodios = episodios;
    }

    public List<Integer> getQtdEpisodios() {
        return qtdEpisodios;
    }

    public void setQtdEpisodios(List<Integer> qtdEpisodios) {
        this.qtdEpisodios = qtdEpisodios;
    }
}


