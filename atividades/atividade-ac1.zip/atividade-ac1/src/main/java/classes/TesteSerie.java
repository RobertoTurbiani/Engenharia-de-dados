package classes;

public class TesteSerie {

    public static void main(String[] args) {

        Streaming streaming = new Streaming ();
        SerieOriginal serieOriginal01 = new SerieOriginal();
        SerieEspecial serieEspecial01 = new SerieEspecial();
        Musica musica01 = new Musica();

        streaming.tipoServico("Plano Simples");
        serieOriginal01.exibirCatalogo();
        serieOriginal01.selecionarReproducao("Vikings");

        serieOriginal01.iniciarReproducao();
        serieOriginal01.trocarEpisodio();
        serieOriginal01.baixarEpisodio();


        serieEspecial01.exibirCatalogo();
        serieEspecial01.selecionarReproducao("Loki");

        serieEspecial01.iniciarReproducao();
        serieEspecial01.trocarEpisodio();
        serieEspecial01.alugarSerie("Loki");

        musica01.exibirCatalogo();
        musica01.selecionarReproducao("One");
        musica01.iniciarReproducao();
        musica01.baixarMusica("One");

    }
}
