package classes;

public interface IStreaming {

   Double tipoServico(String tipoDePlano);


}
