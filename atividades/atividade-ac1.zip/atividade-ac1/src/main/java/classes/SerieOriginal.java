package classes;

import java.util.ArrayList;
import java.util.List;

public class SerieOriginal extends Serie {

    private List<String> listaSerie = new ArrayList<>(List.of("Game of Thrones", "Vikings", "Supernatural"));
    private List<Integer> listaEpisodio = new ArrayList<>(List.of(1,2,3,4,5));
    private  List<Integer> episodiosBaixados = new ArrayList<>();
    private String serieSelecionada;
    private Integer episodioAtual = 1;

    @Override
    public void iniciarReproducao() {

        if (serieSelecionada != null){
            System.out.println("Iniciando a Reprodução da série: " + serieSelecionada + " aguarde um momento...");
        } else {
            System.out.println("Escolha uma série para comerçarmos");
        }
    }

    @Override
    public void exibirCatalogo() {

        for (int i = 0; i <listaSerie.size() && i < listaEpisodio.size() ; i++) {
            System.out.println("séries no catálogo Original: " + listaSerie.get(i) + "\n");

        }

    }

    @Override
    public void selecionarReproducao(String nomeSerie ) {

        if (listaSerie.contains(nomeSerie)){
            System.out.println("série: " + nomeSerie + " Escolhida");
            serieSelecionada = nomeSerie;
        } else {
            System.out.println("A série '" + nomeSerie + "' não está no nosso catálogo.");

        }
    }

    @Override
    public void trocarEpisodio() {

        if (listaSerie != null) {
            System.out.println("Episódio atual:" + episodioAtual);
            for (int i = 0; i < 1; i++) {
                if (episodioAtual < listaEpisodio.size()) {

                    episodioAtual ++;
                    System.out.println("Iniciando o próximo episódio, episódio:" + episodioAtual);
                } else {
                    System.out.println("Esse é o ultimo episódio ");
                }
            }
        }
    }

    public void baixarEpisodio(){
            for (int i = episodiosBaixados.size(); i < listaEpisodio.size(); i++) {
                episodioAtual = i +1;
                if (episodiosBaixados.size() == 4){
                    break;
                } else {
                    episodiosBaixados.add(episodioAtual);
                }
                System.out.println("Baixando episódio %d".formatted(episodioAtual));

            }

        }

    }

