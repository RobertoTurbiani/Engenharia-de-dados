import java.util.Scanner;
public class Main {

    public static void exibe (int[][] matriz){

        for (int linha = 0; linha < matriz.length ; linha++) {
            for (int coluna = 0; coluna < matriz[0].length ; coluna++) {
                System.out.printf(matriz[linha][coluna] + "\t");
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        int[] vetor = new int[4];

        int[][] matriz = new int[3][4];

        int[][] matrizValoresIniciais = {{10,15,20,25},{30,35,40,45},{50,55,60,65}};
        int[][] matrizInversa = {{10,15,20,25},{30,35,40,45},{50}, {10,30,50,60}};

        for (int linha = 0; linha < matriz.length ; linha++) {
            for (int coluna = 0; coluna < matriz[0].length ; coluna++) {
                System.out.println("Preencha a matriz em [" + linha + "][" + coluna + "]");
                matriz[linha][coluna] = leitor.nextInt();
            }
        }


        for (int coluna = 0; coluna <matriz[0].length; coluna++) {
            for (int linha = 0; linha <matriz.length; linha++) {
                System.out.printf(matriz[linha][coluna] + "\t");

            }
            System.out.println();
        }

    }
}