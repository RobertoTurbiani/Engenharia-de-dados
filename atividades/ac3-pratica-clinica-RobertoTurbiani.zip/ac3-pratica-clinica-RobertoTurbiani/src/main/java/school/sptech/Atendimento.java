package school.sptech;

public class Atendimento {

    // Atributos
    private FilaObj<Pet> filaPrioritaria;
    private FilaObj<Pet> filaNormal;
    private String[] raca;
    private double[] mediaColuna;
    private double[] mediaLinha;
    private double[][] matrizRelatorio;

    public Atendimento(String[] raca, int qtdLinha, int qtdColuna) {
        this.raca = raca;
        this.matrizRelatorio = new double[qtdLinha][qtdColuna];
        filaPrioritaria = new FilaObj(10);
        filaNormal = new FilaObj(10);
        mediaColuna = new double[matrizRelatorio[0].length];
        mediaLinha = new double[matrizRelatorio.length];
    }

    // Métodos (completar)
    public void triagem(Pet p) {

        if (p.getMotivo().equals("Envenenamento")
                || p.getMotivo().equals("Hemorragia")) {
            filaPrioritaria.insert(p);
        } else {
            filaNormal.insert(p);

        }
    }

    public Pet[] atender(int qtdPetChamado) {

        if (filaNormal.isEmpty() || filaPrioritaria.isEmpty()) {
            throw new IllegalStateException();
        }

        if (qtdPetChamado <= 0 || qtdPetChamado > filaPrioritaria.getTamanho()
                || qtdPetChamado > filaNormal.getTamanho()) {
            throw new IllegalArgumentException();
        }

        Pet vetorAuxiliar[] = new Pet[qtdPetChamado];
        for (int i = 0; i < vetorAuxiliar.length; i++) {
            if (filaPrioritaria.getTamanho() <=0) {
                vetorAuxiliar[i] = filaNormal.poll();
            } else {
                vetorAuxiliar[i] = filaPrioritaria.poll();
            }
        }
        return vetorAuxiliar;
    }

    public void vetorParaMatriz(int[] vetor) {
        int capacidadeMatriz = matrizRelatorio.length * matrizRelatorio[0].length;

        if (vetor.length != capacidadeMatriz) {
            throw new IllegalArgumentException();
        }

        int aux = 0;
        for (int linha = 0; linha < matrizRelatorio.length; linha++) {
            for (int coluna = 0; coluna < matrizRelatorio[0].length; coluna++) {
                matrizRelatorio[linha][coluna] = vetor[aux++];
            }
        }
    }

    public void calculaMediaLinha() {

        mediaLinha = new double[matrizRelatorio.length];

        for (int i = 0; i < matrizRelatorio.length; i++) {
            double aux = 0;
            for (int j = 0; j < matrizRelatorio[i].length; j++) {
                aux += matrizRelatorio[i][j];
            }
            mediaLinha[i] = aux / matrizRelatorio[i].length;
        }
    }

    public void calculaMediaColuna() {

        mediaColuna = new double[matrizRelatorio.length];

        for (int i = 0; i < matrizRelatorio.length; i++) {
            double aux = 0;
            for (int j = 0; j < matrizRelatorio[i].length; j++) {
                aux += matrizRelatorio[i][j];
            }
            mediaColuna[i] = aux / matrizRelatorio[i].length;
        }

    }

    public void exibeRelatorio() {

    }

    // Getters (não retirar)
    public double[] getMediaColuna() {
        return mediaColuna;
    }
    public double[] getMediaLinha() {
        return mediaLinha;
    }
    public double[][] getMatrizRelatorio() {
        return matrizRelatorio;
    }
    public FilaObj<Pet> getFilaPrioritaria() {
        return filaPrioritaria;
    }
    public FilaObj<Pet> getFilaNormal() {
        return filaNormal;
    }
}
