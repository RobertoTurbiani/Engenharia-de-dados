package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class Repositorio {

    // Atributos
    private List<Recurso> lista;
    private PilhaObj<Integer> pilhaDesfazer;
    private PilhaObj<Integer> pilhaRefazer;

    // Construtor
     public Repositorio() {
        lista = new ArrayList();
        pilhaDesfazer = new PilhaObj(10);
        pilhaRefazer = new PilhaObj(10);
    }

    // Métodos
    public void salvar(Recurso r) {
        if (r != null){
            lista.add(r);
        }
     }

    public void diminuiRecurso(int valorDiminuicao) {
        for (int i = 0; i <lista.size() ; i++) {
            lista.get(i).setQuantidade(lista.get(i).getQuantidade() - valorDiminuicao);
        }
    }

    public void aumentaRecurso(int valorAumento) {
        for (int i = 0; i <lista.size() ; i++) {
            lista.get(i).setQuantidade(lista.get(i).getQuantidade() + valorAumento);
        }
    }

    public void desfazer() {

        for (int i = 0; i < lista.size() ; i++) {

            if (!pilhaDesfazer.isEmpty()) {
                int valorDesfazer = pilhaDesfazer.pop();
                aumentaRecurso(valorDesfazer);
                pilhaRefazer.push(valorDesfazer);
            } else {
                throw new IllegalStateException();
            }
        }
     }

    public void refazer() {

        if (!pilhaRefazer.isEmpty()) {
            int valorRefazer = pilhaRefazer.pop();
            diminuiRecurso(valorRefazer);
        } else {
            throw new IllegalStateException();
        }
    }

    // Getters (não retirar)
    public List<Recurso> getLista() {
        return lista;
    }

    public PilhaObj<Integer> getPilhaDesfazer() {
        return pilhaDesfazer;
    }

    public PilhaObj<Integer> getPilhaRefazer() {
        return pilhaRefazer;
    }
}

