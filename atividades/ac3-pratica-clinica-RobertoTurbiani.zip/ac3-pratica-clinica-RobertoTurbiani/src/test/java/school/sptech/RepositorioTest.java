package school.sptech;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Repositorio")
public class RepositorioTest {

    @Test
    @DisplayName("Salva corretamente os recursos")
    public void salvarTest() {
        Repositorio repo = new Repositorio();
        repo.salvar(new Recurso(100, "Enfermeiro", 30));
        repo.salvar(new Recurso(101, "Aparelho Raio-X", 3));
        repo.salvar(new Recurso(102, "Veterinario Cirurgiao", 5));
        repo.salvar(new Recurso(103, "Veterinario Plantonista", 15));
        assertEquals(4, repo.getLista().size());
        assertEquals(100, repo.getLista().get(0).getId());
        assertEquals(103, repo.getLista().get(3).getId());
    }

    @Test
    @DisplayName("Aumenta corretamente a quantidade de recursos")
    public void aumentarRecursoTest() {
        Repositorio repo = new Repositorio();
        repo.salvar(new Recurso(100, "Enfermeiro", 30));
        repo.salvar(new Recurso(101, "Aparelho Raio-X", 3));
        repo.salvar(new Recurso(102, "Veterinario Cirurgiao", 5));
        repo.salvar(new Recurso(103, "Veterinario Plantonista", 15));
        repo.aumentaRecurso(10);
        assertEquals(40, repo.getLista().get(0).getQuantidade());
        assertEquals(13, repo.getLista().get(1).getQuantidade());
        assertEquals(15, repo.getLista().get(2).getQuantidade());
        assertEquals(25, repo.getLista().get(3).getQuantidade());
    }

    @Test
    @DisplayName("Diminui corretamente a quantidade de recursos")
    public void diminuirRecursoTest() {
        Repositorio repo = new Repositorio();
        repo.salvar(new Recurso(100, "Enfermeiro", 30));
        repo.salvar(new Recurso(101, "Aparelho Raio-X", 3));
        repo.salvar(new Recurso(102, "Veterinario Cirurgiao", 5));
        repo.salvar(new Recurso(103, "Veterinario Plantonista", 15));
        repo.diminuiRecurso(2);
        assertEquals(28, repo.getLista().get(0).getQuantidade());
        assertEquals(1, repo.getLista().get(1).getQuantidade());
        assertEquals(3, repo.getLista().get(2).getQuantidade());
        assertEquals(13, repo.getLista().get(3).getQuantidade());
    }

    @Test
    @DisplayName("Desfaz corretamente a diminuição da quantidade de recursos")
    public void desfazerTest() {
        Repositorio repo = new Repositorio();
        repo.salvar(new Recurso(100, "Enfermeiro", 30));
        repo.salvar(new Recurso(101, "Aparelho Raio-X", 4));
        repo.salvar(new Recurso(102, "Veterinario Cirurgiao", 5));
        repo.salvar(new Recurso(103, "Veterinario Plantonista", 15));
        assertThrows(IllegalStateException.class, () -> repo.desfazer());

        repo.diminuiRecurso(1);
        repo.diminuiRecurso(2);
        repo.desfazer();
        assertEquals(29, repo.getLista().get(0).getQuantidade());
        assertEquals(3, repo.getLista().get(1).getQuantidade());
        assertEquals(4, repo.getLista().get(2).getQuantidade());
        assertEquals(14, repo.getLista().get(3).getQuantidade());

    }

    @Test
    @DisplayName("Refaz corretamente a diminuição da quantidade de recursos")
    public void refazerTest() {
        Repositorio repo = new Repositorio();
        repo.salvar(new Recurso(300, "Enfermeiro", 30));
        repo.salvar(new Recurso(301, "Aparelho Raio-X", 4));
        repo.salvar(new Recurso(302, "Medico Cirurgiao", 5));
        repo.salvar(new Recurso(303, "Medico Plantonista", 15));
        repo.diminuiRecurso(2);
        repo.desfazer();
        assertEquals(30, repo.getLista().get(0).getQuantidade());
        assertEquals(4, repo.getLista().get(1).getQuantidade());
        assertEquals(5, repo.getLista().get(2).getQuantidade());
        assertEquals(15, repo.getLista().get(3).getQuantidade());
        repo.refazer();
        assertEquals(28, repo.getLista().get(0).getQuantidade());
        assertEquals(2, repo.getLista().get(1).getQuantidade());
        assertEquals(3, repo.getLista().get(2).getQuantidade());
        assertEquals(13, repo.getLista().get(3).getQuantidade());

        assertThrows(IllegalStateException.class, () -> repo.refazer());
    }
}
