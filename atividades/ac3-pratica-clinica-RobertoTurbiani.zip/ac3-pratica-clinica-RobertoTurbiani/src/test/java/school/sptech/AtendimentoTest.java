package school.sptech;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Atendimento")
public class AtendimentoTest {

    @Test
    @DisplayName("Insere corretamente os pets nas filas")
    public void triagemTest() {
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        atendimento.triagem(new Pet(2000, "Thor", "Pastor alemão", "Diarreia"));
        assertEquals(1, atendimento.getFilaNormal().getTamanho());
        assertEquals(0, atendimento.getFilaPrioritaria().getTamanho());
        atendimento.triagem(new Pet(2001, "Melly", "Maltês", "Hemorragia"));
        assertEquals(1, atendimento.getFilaNormal().getTamanho());
        assertEquals(1, atendimento.getFilaPrioritaria().getTamanho());
        atendimento.triagem(new Pet(2002, "Pipoca", "Yorkshire", "Envenenamento"));
        assertEquals(1, atendimento.getFilaNormal().getTamanho());
        assertEquals(2, atendimento.getFilaPrioritaria().getTamanho());
        atendimento.triagem(new Pet(2003, "Flash", "Vira lata", "Vômito"));
        assertEquals(2, atendimento.getFilaNormal().getTamanho());
        assertEquals(2, atendimento.getFilaPrioritaria().getTamanho());

        assertEquals("Melly", atendimento.getFilaPrioritaria().peek().getNome());
        assertEquals("Thor", atendimento.getFilaNormal().peek().getNome());
        atendimento.getFilaPrioritaria().poll();
        atendimento.getFilaNormal().poll();
        assertEquals("Pipoca", atendimento.getFilaPrioritaria().peek().getNome());
        assertEquals("Flash", atendimento.getFilaNormal().peek().getNome());
    }

    @Test
    @DisplayName("Deve validar corretamente se filas não vazia e se argumento correto")
    public void atenderValidacoes() {
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        assertThrows(IllegalStateException.class, () -> atendimento.atender(2));

        atendimento.triagem(new Pet(2000, "Thor", "Pastor alemão", "Diarreia"));
        atendimento.triagem(new Pet(2001, "Melly", "Maltês", "Envenenamento"));
        atendimento.triagem(new Pet(2002, "Pipoca", "Yorkshire", "Hemorragia"));

        assertThrows(IllegalArgumentException.class, () -> atendimento.atender(-1));
        assertThrows(IllegalArgumentException.class, () -> atendimento.atender(0));
        assertThrows(IllegalArgumentException.class, () -> atendimento.atender(4));
    }

    @Test
    @DisplayName("Deve retornar vetor com 1 Pet")
    public void atender1() {
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        atendimento.triagem(new Pet(2000, "Thor", "Pastor alemão", "Diarreia"));
        atendimento.triagem(new Pet(2001, "Melly", "Maltês", "Envenenamento"));
        atendimento.triagem(new Pet(2002, "Pipoca", "Yorkshire", "Hemorragia"));

        Pet[] vetor = atendimento.atender(1);
        assertEquals(1, atendimento.getFilaPrioritaria().getTamanho());
        assertEquals(1, atendimento.getFilaNormal().getTamanho());
        assertEquals(1, vetor.length);
        assertEquals(2001, vetor[0].getId());
    }

    @Test
    @DisplayName("Deve retornar vetor com 2 Pets prioritarios")
    public void atender2() {
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        atendimento.triagem(new Pet(2000, "Thor", "Pastor alemão", "Diarreia"));
        atendimento.triagem(new Pet(2001, "Melly", "Maltês", "Envenenamento"));
        atendimento.triagem(new Pet(2002, "Pipoca", "Yorkshire", "Hemorragia"));

        Pet[] vetor = atendimento.atender(2);
        assertEquals(0, atendimento.getFilaPrioritaria().getTamanho());
        assertEquals(1, atendimento.getFilaNormal().getTamanho());
        assertEquals(2, vetor.length);
        assertEquals(2001, vetor[0].getId());
        assertEquals(2002, vetor[1].getId());
    }

    @Test
    @DisplayName("Deve retornar vetor com 2 Pets prioritarios e 1 normal")
    public void atender3() {
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        atendimento.triagem(new Pet(2000, "Thor", "Pastor alemão", "Diarreia"));
        atendimento.triagem(new Pet(2001, "Melly", "Maltês", "Envenenamento"));
        atendimento.triagem(new Pet(2002, "Pipoca", "Yorkshire", "Hemorragia"));

        Pet[] vetor = atendimento.atender(3);
        assertEquals(0, atendimento.getFilaPrioritaria().getTamanho());
        assertEquals(0, atendimento.getFilaNormal().getTamanho());
        assertEquals(3, vetor.length);
        assertEquals(2001, vetor[0].getId());
        assertEquals(2002, vetor[1].getId());
        assertEquals(2000, vetor[2].getId());
    }

    @Test
    @DisplayName("Deve retornar vetor com 2 Pets normais")
    public void atender4() {
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        atendimento.triagem(new Pet(2000, "Thor", "Pastor alemão", "Diarreia"));
        atendimento.triagem(new Pet(2001, "Melly", "Maltês", "Vômito"));
        atendimento.triagem(new Pet(2002, "Pipoca", "Yorkshire", "Pata machucada"));

        Pet[] vetor = atendimento.atender(2);
        assertEquals(0, atendimento.getFilaPrioritaria().getTamanho());
        assertEquals(1, atendimento.getFilaNormal().getTamanho());
        assertEquals(2, vetor.length);
        assertEquals(2000, vetor[0].getId());
        assertEquals(2001, vetor[1].getId());
    }

    @Test
    @DisplayName("Tamanho do vetor não pode ser menor nem maior do que tam da matriz")
    public void vetorParaMatrizValidaVetor() {
        int[] vetor = {1, 2, 3};
        int[] vetor1 = {1, 2, 3, 4, 5, 6};
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        assertThrows(IllegalArgumentException.class, () -> atendimento.vetorParaMatriz(vetor));
        assertThrows(IllegalArgumentException.class, () -> atendimento.vetorParaMatriz(vetor1));
    }

    @Test
    @DisplayName("Valores do vetor devem ser atribuidos corretamente para a matriz")
    public void vetorParaMatrizVerificaValor() {
        int[] vetor = {1, 2, 3, 4};
        String[] raca = {"Raça1", "Raça2"};
        Atendimento atendimento = new Atendimento(raca, 2, 2);

        atendimento.vetorParaMatriz(vetor);
        double[][] matriz = atendimento.getMatrizRelatorio();
        assertEquals(1, matriz[0][0]);
        assertEquals(3, matriz[0][1]);
        assertEquals(2, matriz[1][0]);
        assertEquals(4, matriz[1][1]);
    }

    @Test
    @DisplayName("Calcula corretamente as médias das linhas, as médias das colunas e exibe o relatorio")
    public void calculaMedias() {
        int[] vetor = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21};
        String[] raca = {"Pastor alemão", "Maltês", "Yorkshire", "Labrador", "Poodle", "Beagle", "Vira lata"};
        Atendimento atendimento = new Atendimento(raca, 7, 3);

        atendimento.vetorParaMatriz(vetor);
        atendimento.calculaMediaLinha();
        assertEquals(8, atendimento.getMediaLinha()[0]);
        assertEquals(9, atendimento.getMediaLinha()[1]);
        assertEquals(10, atendimento.getMediaLinha()[2]);
        assertEquals(11, atendimento.getMediaLinha()[3]);
        assertEquals(12, atendimento.getMediaLinha()[4]);
        assertEquals(13, atendimento.getMediaLinha()[5]);
        assertEquals(14, atendimento.getMediaLinha()[6]);

        atendimento.calculaMediaColuna();
        assertEquals(4, atendimento.getMediaColuna()[0]);
        assertEquals(11, atendimento.getMediaColuna()[1]);
        assertEquals(18, atendimento.getMediaColuna()[2]);

        atendimento.exibeRelatorio();
    }

}
