[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/4ieHIxvs)
# Avaliação Continuada 03 - Prática

## 🐾 Programa para Clinica Veterinaria 
Foi desenvolvido um programa em Java para uma Clinica Veterinaria. Esse programa conta com um repositório responsável por armazenar informações essenciais para o funcionamento da clinica.

### Recursos do Clinica Veterinaria:
Um dos papeis do Repositório é fazer controle dos recursos que a clinica possui (recurso pode ser um Veterinario Cirurgião, Aparelho de Raio X, Enfermeiro, etc)
- Para isso, foi criada uma classe `Repositorio` que utiliza `List<Recurso>` como meio de armazenamento, por questões de desempenho.
Ocasionalmente, há necessidade de diminuir os recursos da clinica, como em um período com menos atendimentos, e depois volta ao normal. A diminuição de recursos da clinica dessa forma é uma operação que pode ser desfeita e cada operação desfeita também pode ser refeita
- Para isso, foi criado na classe `Repositorio` 2 atributos do tipo `PilhaObj<Integer>`, sendo `pilhaDesfazer` e `pilhaRefazer`

### Filas do Hospital
Além do controle de Repositorio, a clínica organiza os pets em 2 filas, uma fila de pet prioritários e uma fila de pets não prioritários. Em um determinado momento, vários veterinarios plantonistas chamam os próximos pets a serem atendidos.
- Para isso, foi criada uma classe `Atendimento` que possui 2 atributos do tipo `FilaObj<Paciente>`, sendo `filaNormal` e `filaPrioritaria`

## 🛠️ Implementação (Código)
- No projeto, todas as classes foram criadas, ou seja, não é necessário adicionar classes novas, apenas completar o código do projeto.
- Leia com atenção para entender quais classes já estão completas, e quais necessitam preenchimento de código, para ajudar, usamos os emojis:
  - ✅ = Código completo, não é necessário alterar
  - ⚠️ = Código incompleto, necessário preencher o restante. Nos métodos, completar apenas o corpo (conteúdo), a assinatura já está completa (retorno e argumentos).
  - Recomendamos terminar a leitura antes da codificação
  - O projeto possui testes automatizados para ajudar a identificar se os métodos estão corretos (alguns métodos dependem de outros para passar nos testes).
##
### ✅ Classe `Recurso`: essa classe já está completa no projeto, não é necessário alterar nada
- Atributos encapsulados:
  - `id`, inteiro
  - `nome`, String (nome do recurso)
  - `quantidade`, int (quantidade disponível do recurso)
- Construtor cheio que inicializa os atributos
- Getters e setters
- toString
##
### Classe `Pet`: essa classe já está completa no projeto, não é necessário alterar nada
### ✅ Encapsulamento: 
- Atributos:
  - `id`, inteiro
  - `nome`, String (nome do pet)
  - `raca` String (raça do pet)
  - `motivo`, String (motivo do atendimento)
- Construtor cheio que inicializa os atributos
- Getters e setters
- toString
##
### Classe `Repositorio`: classe incompleta, os atributos e as assinaturas dos métodos já foram criados, necessário completar apenas o corpo dos métodos
### ✅ Encapsulamento: 
- Atributos: 
  - `lista` - List de Recurso
  - `pilhaDesfazer` – PilhaObj de Integer
  - `pilhaRefazer` – PilhaObj de Integer
- Construtor: instancia a lista, a `pilhaDesfazer` e a `pilhaRefazer`
  
### ⚠️ Método `salvar`:
- Recebe um objeto Recurso e adiciona na lista

### ⚠️ Método `diminuiRecurso` 
- Recebe a quantidade a diminuir
- Percorre a lista de recursos e subtrai o `valorDiminuicao` do atributo `quantidade` de cada recurso da lista (por exemplo: se o argumento for 10, a quantidade de cada recurso deve ser o valor antigo da quantidade menos 10)
- Como essa operação pode ser desfeita, empilha o valor do aumento na `pilhaDesfazer`
  
### ⚠️ Método `aumentaRecurso` 
- Recebe a quantidade a aumentar
- Percorre a lista de recursos e soma o `valorDiminuicao` do atributo `quantidade` de cada recurso da lista

### ⚠️ Método `desfazer` 
- Não recebe argumentos
- Se a `pilhaDesfazer` estiver vazia, lança exceção `IllegalStateException`
- Se a `pilhaDesfazer` não estiver vazia, desempilha um valor e faz o "inverso do diminuiRecurso", ou seja, chama o método `aumentaRecurso` com a quantidade desempilhada
- Como a operação pode ser refeita, empilha a quantidade desempilhada na `pilhaRefazer`

### ⚠️ Método `refazer` 
- Não recebe argumentos
- Se a `pilhaRefazer` estiver vazia, lança exceção `IllegalStateException`
- Se a `pilhaRefazer` não estiver vazia, desempilha um valor e "refaz o diminuiRecurso", ou seja, chama o método `diminuiRecurso` passando esse valor desempilhado

##
### Classe `Atendimento`: classe incompleta, os atributos e as assinaturas dos métodos já foram criados, necessário completar apenas o corpo dos métodos
### ✅ Encapsulamento: 
- Atributos:
  - `filaPrioritaria` – FilaObj de Pets
  - `filaNormal` – FilaObj de Pets
  - `raca` – vetor String de nomes de raças (usado para exibir o relatório)
  - `matrizRelatorio` - matriz double contendo quantidades de pets atendidos em meses diferentes (usado para exibir o relatório)
  - `mediaLinha` - vetor double que vai conter as médias das linhas da `matrizRelatorio` (usado para o relatório)
  - `mediaColuna` - vetor double que vai conter as médias das colunas da `matrizRelatorio` (usado para o relatório)
- Construtor:  recebe como argumento o vetor `raca`, a quantidade de linhas e de colunas da matriz
  - Instancia as filas
  - Inicializa o vetor `raca`
  - Instancia a `matrizRelatorio` com a quantidade de linhas e colunas recebida como argumento
  - Instancia `mediaLinha` com o tamanho de quantidade de linhas recebida como argumento
  - Instancia `mediaColuna` com o tamanho de quantidade de colunas recebida como argumento

### ⚠️ Método `triagem`
- Recebe um objeto `Pet` como argumento
- Se o pet for prioritario, insere-o na `filaPrioritaria` (um pet é prioritario quando o atributo `motivo` for igual a "Envenenamento" ou "Hemorragia")
- Se o pet não for prioritario, insere-o na `filaNormal`

### ⚠️ Método `atender`
- Recebe a quantidade de pets a serem chamados
- Retorna um vetor com os pets que devem ser atendidos
- Se as filas estão vazias, lança `IllegalStateException`
- Se a quantidade de pets a serem chamados for menor ou igual a zero ou maior do que o tamanho das filas, lança `IllegalArgumentException`
- Cria um vetor auxiliar de Pet com o tamanho igual a `qtdPetChamado` recebida como argumento
- Tira a quantidade de pets desejada das filas, tirando primeiro os pets da `filaPrioritaria`, e coloca cada pet no vetor auxiliar
- Retorna o vetor auxiliar

### ⚠️ Método `vetorParaMatriz`: 
- Recebe um vetor de inteiros
- Copia o conteúdo do `vetor` recebido para o atributo matrizRelatorio da classe
- Se a quantidade de valores do `vetor` for menor ou maior do que a quantidade de valores que cabe na `matrizRelatorio`, lança exceção de `IllegalArgumentException` (pense em como aplicar a lógica para saber quantos elementos cabem na matriz)
- Os valores devem ser copiados preenchendo linha por linha.
  - Por exemplo, se o vetor tiver os valores `10, 20, 30, 40`
  - A matriz terá os valores:
      ```
      10 20
      30 40
      ```
- Este método deve funcionar para que funcionem os métodos `calculaMediaLinha`, `calculaMediaColuna` e `exibeRelatorio`

### ⚠️ Método `calculaMediaLinha`: 
- Não recebe argumento
- Calcula a média de cada linha da `matrizRelatorio`, colocando a média de cada linha no vetor `mediaLinha` criado como atributo da classe. 
- Não preencha manualmente os valores da `matrizRelatorio`, considere que os dados já foram preenchidos
  
### ⚠️ Método `calculaMediaColuna`: 
- Não recebe argumento
- Calcula a média de cada coluna da `matrizRelatorio`, colocando a média de cada coluna no vetor `mediaColuna`
- Não preencha manualmente os valores da `matrizRelatorio`, considere que os dados já foram preenchidos
  
### ⚠️ Método `exibeRelatorio`
- Não recebe argumentos
- Não preencha manualmente os valores dos vetores e da matriz, considere que os dados já foram preenchidos
- Exibe o relatório usando saída formatada, de forma que:
  - A 1ª coluna seja os nomes das raças (atributo vetor `raca`)  
  - As 2ª, 3ª e 4ª colunas são os dados da `matrizRelatorio`, sendo que:
    - As linhas da matriz representam as raças
    - As colunas representam a quantidade de pets atendidos de cada raça nos meses de abril, maio e junho
  - A 5ª coluna seja a média das linhas da matriz (atributo vetor `mediaLinha`)
  - A última linha do relatório deve ser as médias das colunas
  - Não se esqueça dos títulos das colunas na exibição
  - Valores de texto devem ser exibidos alinhados à esquerda
  - Valores numéricos devem ser exibidos alinhados à direita

Exemplo de como deve ser o relatório (não precisa ter os | )

`| DOENÇA    |      ABRIL |       MAIO |      JUNHO |      MÉDIA |`

`| Labrador  |      10,00 |      11,00 |      12,00 |      11,00 |`

`| Poodle    |     100,00 |     200,00 |     300,00 |     200,00 |`

`| MÉDIA     |      55,00 |     105,00 |     156,00 |            |`




### ✅ Classes `FilaObj` e `PilhaObj`: completas conforme vimos em aula

