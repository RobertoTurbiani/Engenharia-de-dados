import java.util.Scanner;

public class Main {
    public static void matriz2Por3(int[][] matriz){

        for (int linha = 0; linha < matriz.length ; linha++) {
            for (int coluna = 0; coluna <matriz[0].length ; coluna++) {
                System.out.printf(matriz[linha][coluna] + "\t");
            }
            System.out.println();
        }
    }

    public static void exibeMatriz(int [][] matriz){



        System.out.println("matriz 01");
        for (int linha = 0; linha < matriz.length ; linha++) {
            for (int coluna = 0; coluna <matriz[0].length ; coluna++) {
                System.out.printf(matriz[linha][coluna] + "\t");
            }
            System.out.println();
        }

        System.out.println("matriz 02");
        for (int linha = 0; linha < matriz.length ; linha++) {
            for (int coluna = 0; coluna <matriz[0].length ; coluna++) {
                System.out.printf(matriz[linha][coluna] + "\t");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        int[] vetor = new int[4];

        int[][] matriz = new int[2][3];

        for (int linha = 0; linha < matriz.length ; linha++) {
            for (int coluna = 0; coluna < matriz[0].length ; coluna++) {
                System.out.println("Preencha a matriz em [" + linha + "][" + coluna + "]");
                matriz[linha][coluna] = leitor.nextInt();
            }
        }

//        matriz2Por3(matriz);
        exibeMatriz(matriz);
    }
}