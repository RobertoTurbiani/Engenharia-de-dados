public class Main {
    public static void main(String[] args) {


        ListaLigada listaLigada = new ListaLigada();

        listaLigada.insereNode(1);
        listaLigada.insereNode(20);
        listaLigada.insereNode(300);
        listaLigada.insereNode(4000);

        listaLigada.exibe();

        listaLigada.buscaNode(1).getInfo();
        listaLigada.removeNode(20);


        System.out.println(listaLigada.getTamanho());
        listaLigada.exibe();
    }
}