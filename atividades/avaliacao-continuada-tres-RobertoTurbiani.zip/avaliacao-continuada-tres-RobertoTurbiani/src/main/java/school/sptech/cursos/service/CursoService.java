package school.sptech.cursos.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import school.sptech.cursos.entity.Curso;
import school.sptech.cursos.repository.CursoRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CursoService {

    private final CursoRepository cursoRepository;


    public List<Curso> findAll() {
        List<Curso> cursos = cursoRepository.findAll();
        if (cursos.isEmpty()) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(204));
        }
        return cursos;
    }

    public Curso findById(Integer id) {

        return cursoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatusCode.valueOf(404)));
    }

    public Curso save(Curso curso) {
        if (cursoRepository.existsByNome(curso.getNome())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Nome do curso já utilizado");
        }

        if (curso.getCargaHoraria() == null || curso.getCargaHoraria() < 1) {
            ResponseEntity.status(400).build();
        }
        return cursoRepository.save(curso);
    }
}
