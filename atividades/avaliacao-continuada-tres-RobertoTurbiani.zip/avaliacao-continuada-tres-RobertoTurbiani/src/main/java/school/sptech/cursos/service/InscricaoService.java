package school.sptech.cursos.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import school.sptech.cursos.entity.Curso;
import school.sptech.cursos.entity.Inscricao;
import school.sptech.cursos.repository.CursoRepository;
import school.sptech.cursos.repository.InscricaoRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InscricaoService {
    private final InscricaoRepository inscricaoRepository;
    private final CursoRepository cursoRepository;

    public List<Inscricao> findAll() {
        List<Inscricao> inscricaos = inscricaoRepository.findAll();
        if (inscricaos.isEmpty()) {
            throw new ResponseStatusException(HttpStatusCode.valueOf(204));
        }
        return inscricaos;
    }

    public Inscricao findById(Integer id) {

        return inscricaoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatusCode.valueOf(404)));
    }

    public Inscricao save(Inscricao inscricao, Integer idCurso) {
      // não permita salvar com o nome em branco
        if (inscricao.getNome() == null || inscricao.getNome().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Nome da inscrição não pode ser vazio");
        }
        Curso curso = cursoRepository.findById(idCurso)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Curso não encontrado"));
        inscricao.setCurso(curso);
        return inscricaoRepository.save(inscricao);
    }

    public void delete(Integer id) {
        
    }
}
