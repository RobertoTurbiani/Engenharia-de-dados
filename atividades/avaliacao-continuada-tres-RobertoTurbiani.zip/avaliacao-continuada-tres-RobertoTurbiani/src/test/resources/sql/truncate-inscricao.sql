truncate table inscricao;
