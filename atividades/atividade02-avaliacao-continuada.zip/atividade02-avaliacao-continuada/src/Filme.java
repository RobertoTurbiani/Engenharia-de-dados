public class Filme {
    private String nome;
    private Integer anoLancamento;
    private Double preco;
    private Integer id;
    private String descricao;
    private String diretor;

    public Filme(String nome, Integer anoLancamento, Double preco, Integer id, String descricao, String diretor) {
        this.nome = nome;
        this.anoLancamento = anoLancamento;
        this.preco = preco;
        this.id = id;
        this.descricao = descricao;
        this.diretor = diretor;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(Integer anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDiretor() {
        return diretor;
    }

    public void setDiretor(String diretor) {
        this.diretor = diretor;
    }

    @Override
    public String toString() {
        return """
                Nome: %s
                Ano de lançamento: %d
                Preço: %.2f
                Id: %d
                Descrição: %s
                Nome do Diretor: %s
                """.formatted(nome,anoLancamento,preco,id,descricao,diretor);
    }
}
