import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

    public static void ordenacaoBubble(Filme[] filmes){
        for (int i = 0; i < filmes.length - 1; i++) {
            for (int j = i + 1; j <filmes.length ; j++) {
                if (filmes[i].getAnoLancamento() > filmes[j].getAnoLancamento()){
                    Filme aux = filmes[i];
                    filmes[i] = filmes[j];
                    filmes[j] = aux;
                }
            }
        }
    }

    public static void ordenacaoBubbleInversa(Filme[] filmes){

        for (int i = filmes.length -1; i >= 0 ; i--) {
            for (int j = filmes.length - 1; j >= 0; j--) {
                if (filmes[i].getAnoLancamento() < filmes[j].getAnoLancamento()){
                    Filme aux = filmes[i];
                    filmes[i] = filmes[j];
                    filmes[j] = aux;
                }
            }
        }

    }

    public static void ordenacaoSelection(Filme[] filmes){
        for (int i = 0; i < filmes.length -1 ; i++) {
            int menor = i;
            for (int j = i +1; j < filmes.length ; j++) {
                if (filmes[j].getAnoLancamento() < filmes[menor].getAnoLancamento()){
                   menor = j;
                }
            }

            if (menor != i){
                Filme aux = filmes[i];
                filmes[i] = filmes[menor];
                filmes[menor] = aux;
            }

        }
    }

    public static void ordenacaoSelectionInversa(Filme[] filmes){
        for (int i = filmes.length - 1; i >= 0 ; i--) {
            int indiceMenor = i;
            for (int j = i -1; j >= 0 ; j--) {
                if (filmes[j].getAnoLancamento() < filmes[indiceMenor].getAnoLancamento()){
                    indiceMenor = j;
                }
            }

            if (indiceMenor != i){
                Filme aux = filmes[i];
                filmes[i] = filmes[indiceMenor];
                filmes[indiceMenor] = aux;
            }

        }
    }

    public static int pesquisaBinaria (Filme[] filmes, int valor){
        int indInf = 0;
        int indSup = filmes.length -1;

        while (indInf <= indSup){
            int meio = (indInf + indSup)/2;

            if (filmes[meio].getAnoLancamento() == valor){
                return meio;
            } else if (valor < filmes[meio].getAnoLancamento()) {
                indSup = meio -1;
            } else {
                indInf = meio +1;
            }
        }

        return  -1;
    }

    public static void exibir(Filme[] filmes){
        for (Filme filme : filmes) {
            System.out.println(filme.getAnoLancamento());
        }

    }

    public static void main(String[] args) {

        Filme[] filmes = new Filme[8];


        Filme filme01 = new Filme("Titanic", 1998,150.,21,"Drama","James");
        Filme filme02 = new Filme("Avatar", 1995,110.,31,"Ação","Mario");
        Filme filme03 = new Filme("Indiana Jones", 1993,150.,441,"Aventura","Carlos");
        Filme filme04 = new Filme("Vikings", 1992,180.,141,"Drama","Harry");
        Filme filme05 = new Filme("Senhor dos  aneis", 2000,170.,431,"Drama","Lucas");
        Filme filme06 = new Filme("Homem aranha", 2001,190.,11,"Heroi","Julia");
        Filme filme07 = new Filme("Vingadores", 2010,120.,1,"Aventura","Renata");
        Filme filme08 = new Filme("Batman", 2020,130.,421,"Heroi","Regina");

        filmes[0] = filme01;
        filmes[1] = filme02;
        filmes[2] = filme03;
        filmes[3] = filme04;
        filmes[4] = filme05;
        filmes[5] = filme06;
        filmes[6] = filme07;
        filmes[7] = filme08;



//      ordenacaoBubble(filmes);
//      ordenacaoSelection(filmes);
//      ordenacaoBubbleInversa(filmes);
        ordenacaoSelectionInversa(filmes);

        exibir(filmes);

        pesquisaBinaria(filmes, 2000);
        System.out.println(pesquisaBinaria(filmes, 2000));

    }

}