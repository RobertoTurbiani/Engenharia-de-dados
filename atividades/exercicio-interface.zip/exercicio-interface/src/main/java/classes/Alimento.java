package classes;

import interfaces.Tributavel;

public class Alimento extends Produto {
    private Integer quantVitamina;

    public Alimento(Integer codigo, String descricao, Double preco, Integer quantVitamina) {
        super(codigo, descricao, preco);
        this.quantVitamina = quantVitamina;
    }

    @Override
    public Double getValorTributo() {
        return getPreco() * 0.15;
    }



    public Integer getQuantVitamina() {
        return quantVitamina;
    }

    public void setQuantVitamina(Integer quantVitamina) {
        this.quantVitamina = quantVitamina;
    }

    @Override
    public String toString() {
        return """
                %s
                Quantidade de Vitamina: %d
                """.formatted(super.toString(),quantVitamina);
    }
}
