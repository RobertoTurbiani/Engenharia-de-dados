package classes;

public class TestaTributo {
    public static void main(String[] args) {

        Alimento alimento01 = new Alimento(13846,"Comestivel",22.50,15);

        Pefume pefume01 = new Pefume(3789,"novidade",100.50,"Lavanda");

        Servico servico01 = new Servico("Personalizado",22.50);

        Tributo tributo01 = new Tributo();

        tributo01.adicionaTributavel(alimento01);
        tributo01.adicionaTributavel(pefume01);
        tributo01.adicionaTributavel(servico01);

        tributo01.exibeTodos();

        System.out.println(tributo01.calcularTotalTributo());
    }
}
