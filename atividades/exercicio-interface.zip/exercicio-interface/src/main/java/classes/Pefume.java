package classes;

public class Pefume extends Produto{

    private String fragancia;

    public Pefume(Integer codigo, String descricao, Double preco, String fragancia) {
        super(codigo, descricao, preco);
        this.fragancia = fragancia;
    }


    @Override
    public Double getValorTributo() {
        return getPreco() * 0.27;
    }

    public String getFragancia() {
        return fragancia;
    }

    public void setFragancia(String fragancia) {
        this.fragancia = fragancia;
    }

    @Override
    public String toString() {
        return """
                %s
                Fragância: %s
                """.formatted(super.toString(),fragancia);
    }
}
