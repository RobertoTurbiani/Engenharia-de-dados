package interfaces;

public interface Tributavel {

public abstract Double getValorTributo();

}
