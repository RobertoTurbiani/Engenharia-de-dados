package school.sptech;
public class Teste {
    public static void separaPositivoNegativoEmOrdem(int[] v){
        FilaObj<Integer> filaPositivos = new FilaObj<>(v.length);
        FilaObj<Integer> filaNegativos = new FilaObj<>(v.length);

        for (int i = 0; i < v.length; i++) {
            if (v[i] >= 0) {
                filaPositivos.insert(v[i]);
            } else {
                filaNegativos.insert(v[i]);
            }
        }

        int i = 0;
        while (!filaPositivos.isEmpty()) {
            v[i++] = filaPositivos.poll();
        }

        while (!filaNegativos.isEmpty()) {
            v[i++] = filaNegativos.poll();
        }
    }

    public static void separaPositivoNegativoOrdemDiferente(int[] v){
        FilaObj<Integer> filaObj = new FilaObj<>(v.length);
        PilhaObj<Integer> pilhaObj = new PilhaObj<>(v.length);

        for (int i = 0; i < v.length; i++) {
            if (v[i] >= 0){
                filaObj.insert(v[i]);
            } else {
                pilhaObj.push(v[i]);
            }
        }

        int i = 0;
        while (!filaObj.isEmpty()) {
            v[i++] = filaObj.poll();
        }

        while (!pilhaObj.isEmpty()) {
            v[i++] = pilhaObj.pop();
        }
    }

    public static void main(String[] args) {
        int[] v = {2,7,-3,-50,45,-4,30,-21,38};

//    separaPositivoNegativoEmOrdem(v);
        separaPositivoNegativoOrdemDiferente(v);

        for (int i = 0; i < v.length; i++) {
            System.out.print(" " + v[i]);
        }
    }
}
