[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/z_im1JGg)
## Exercicio Pilha - Classe Tema 📎
### ⚙️ Configuração do projeto:
- Copie para esse projeto a sua classe tema usada nos exercícios de arquivo csv. 
- Copie também para esse projeto a classe PilhaObj<T>. 

### 🚩 Desafio
Suponha que você vai usar uma classe que representa um repositorio de acesso ao BD, que por questões de performance, armazena os objetos em um List. Esse Repositorio terá as operações de salvar e deletar, e ele **permite que as operações de salvar sejam desfeitas**. 

### 🎲 Crie uma classe chamada `Repositorio`. 
**1.** Atributos encapsulados de Repositorio: 
  - `List<Classe tema> lista` 
  - `PilhaObj<Integer> pilha` 

**2.** Construtor de Repositorio 
    - Instancia os atributos lista e pilha. Pode criar a pilha com tamanho 10. 

**3.** Métodos de Repositorio
  - Método `salvar`: void, recebe como argumento um objeto do tipo ClasseTema. 
    Esse método adiciona esse objeto à lista. Como o método salvar pode ser desfeito, empilha o id do objeto na pilha.
  - Método `deletar`: void, recebe como argumento um inteiro id, do objeto a ser deletado.
    - Esse método verifica se o objeto com id igual ao argumento existe na lista. Se existir, remove esse objeto da lista. Se não existir, exibe a mensagem "ID inexistente".
    - Obs: Não confundam o id do objeto com o índice da lista. O id pode ser 100 e estar no índice zero da lista. Você deve percorrer a lista para encontrar o objeto da lista cujo id seja o id desejado.
    - Para remover da lista, vc pode usar o método remove da lista, passando como argumento o próprio objeto ou o índice (que é diferente do ID) do objeto na lista. Se vc usar uma variável para ser o índice da lista, essa variável deve ser int e não Integer.
  - Método `exibir`:, void, não recebe argumentos.
    - Esse método verifica se a lista está vazia. Se estiver, exibe "Repositório vazio", senão exibe o conteúdo da lista.
    - Esse método também chama o método exibe da pilha.  
  - Método `desfazer`: void, não recebe argumentos.
    - Esse método verifica se a pilha está vazia. Se estiver, exibe mensagem "Não há nada a desfazer". Senão, desempilha um id da pilha e chama o deletar, passando esse id, para desfazer a última operação de salvar. 

### Crie uma classe Teste, no método main: 
- Crie um objeto Repositorio
- Crie um loop, exibindo o menu:
  - ```
      1- Salvar objeto 
      2- Deletar objeto 
      3- Exibir 
      4- Desfazer 
    ```


