package school.sptech;

import java.util.Scanner;

public class Teste {

    public static void menu(){
        System.out.println("""
            
            *---------------------------------------------------------*
            |                Digite a opção:                          |
            |                                                         |
            | 1) Salva objeto.                                        |
            | 2) Deletar objeto.                                      |
            | 3) Exibir                                               |
            | 4) Desfazer ação                                        |
            | 5) Encerrar programa                                    |
            *---------------------------------------------------------*
            """);
    }

    private static void exibir(Repositorio repositorio) {
        repositorio.exibir();
    }

    private static void desfazer(Repositorio repositorio) {
        repositorio.desfazer();
    }


    public static void salvarObjeto(Repositorio repositorio){

        Scanner leitorTexto = new Scanner(System.in);
        Scanner leitorNumero = new Scanner(System.in);

        System.out.print("Qual o id:");
        Integer id = leitorNumero.nextInt();

        System.out.println("Digite o nome do filme");
        String nome = leitorTexto.nextLine();

        System.out.println("Digite o ano de lançamento do filme");
        Integer ano = leitorNumero.nextInt();

        System.out.println("Digite o preço do filme");
        Double preco = leitorNumero.nextDouble();

        System.out.println("Digite a desccrição do filme");
        String descricao = leitorTexto.nextLine();

        System.out.println("Digite o nome do diretor do filme");
        String diretor = leitorTexto.nextLine();

        System.out.println("Digite o nome do ator principal do filme");
        String atorPrincipal = leitorTexto.nextLine();

        Filme filme = new Filme(nome, ano, preco, id, descricao, diretor, atorPrincipal);
        repositorio.salvar(filme);
        System.out.println("Filme cadastrado");
    }

    private static void deletarObjeto(Repositorio repositorio) {
        Scanner leitorNumero = new Scanner(System.in);

        System.out.println("Qual o id do objeto?");
        int id = leitorNumero.nextInt();

        repositorio.deletar(id);
    }

    public static void exibirMenu(Repositorio repositorio){
        Scanner leitorNumero = new Scanner(System.in);

        Integer opcao;

        do {
            menu();
            opcao = leitorNumero.nextInt();

            switch (opcao) {
                case 1 -> {
                    salvarObjeto(repositorio);
                }
                case 2 -> {
                    deletarObjeto(repositorio);
                }
                case 3 ->{
                    exibir(repositorio);
                }
                case 4 ->{
                    desfazer(repositorio);
                }
                case 5 ->{
                    System.out.println("Encerrando programa...");
                }
                default -> {
                    System.out.println("Opção inválida");
                }
            }
        }
        while (opcao != 5);
        
    }

    public static void main(String[] args) {

     Repositorio repositorio = new Repositorio(10);

        exibirMenu(repositorio);

    }
}