package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class Repositorio {


    private final List<Filme> listaFilmes;
    private final PilhaObj<Integer> pilha;

    public Repositorio(int capacidade) {
        this.listaFilmes = new ArrayList<>(capacidade);
        this.pilha = new PilhaObj<>(capacidade);
    }

    public void salvar(Filme filme){
        if (!pilha.isFull()){
            pilha.push(filme.getId());
            listaFilmes.add(filme);
        }
    }

    public void deletar(int id){
        boolean econtrado = false;

        for (int i = 0; i < listaFilmes.size(); i++) {
            if (listaFilmes.get(i).getId() == id){
                listaFilmes.remove(listaFilmes.get(i));
                econtrado = true;
            }
        }

        if(!econtrado) System.out.println("Id não encontrado");
    }

    public void exibir(){
        if (listaFilmes.isEmpty() && pilha.isEmpty()){
            System.out.println("O repositório está vazio");
        } else {
            for (int i = 0; i < listaFilmes.size(); i++) {
                System.out.printf("""
                        Item %d da lista: %s%n""", i, listaFilmes.get(i));
            }

            System.out.print("Id na pilha:");
            pilha.exibe();
        }
    }

    public void desfazer(){
        if(pilha.isEmpty()){
            System.out.println("Não há nada a desfazer");
        } else {
            deletar(pilha.pop());
        }
    }

}
