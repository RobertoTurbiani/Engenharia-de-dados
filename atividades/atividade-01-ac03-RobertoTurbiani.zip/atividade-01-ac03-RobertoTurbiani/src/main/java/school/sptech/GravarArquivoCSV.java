package school.sptech;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class GravarArquivoCSV {

    public static void gravarArquivo(ListaObj<Filme> listaFilme, String nomeArq){

        FileWriter arq = null;
        Formatter saida = null;
        Boolean deuRuim = false;

        nomeArq += ".csv";

// Bloco try-catch para abrir o arquivo
        try {
            arq = new FileWriter(nomeArq);
            saida = new Formatter(arq);
        } catch (IOException erro) {
            System.out.println("Erro ao abrir o arquivo");
            System.exit(1);
        }

// Bloco try-catch para gravar o arquivo
        try {
            for (int i = 0; i < listaFilme.getTamanho(); i++) {
                Filme filme = listaFilme.getElemento(i);
//Recupere um elemento da lista e formate aqui:
                saida.format("%d;%s;%d;%.2f;%s;%s;%s\n",
                        filme.getId(),
                        filme.getNome(),
                        filme.getAnoLancamento(),
                        filme.getPreco(),
                        filme.getDescricao(),
                        filme.getDiretor(),
                        filme.getNomeAtor());
            }
        } catch (FormatterClosedException erro) {
            System.out.println("Erro ao gravar o arquivo");
            deuRuim = true;
        } finally {
            saida.close();
            try {
                arq.close();
            } catch (IOException erro) {
                System.out.println("Erro ao fechar o arquivo");
                deuRuim = true;
            }
            if (deuRuim) {
                System.exit(1);
            }
        }

    }


    public static void leArquivoCsv(String nomeArq) {
        FileReader arq = null;
        Scanner entrada = null;
        Boolean deuRuim = false;

        nomeArq += ".csv";

// Bloco try-catch para abrir o arquivo
        try {
            arq = new FileReader(nomeArq);
            entrada = new Scanner(arq).useDelimiter(";|\\n");
        } catch (FileNotFoundException erro) {
            System.out.println("Arquivo nao encontrado");
            System.exit(1);
        }

// Bloco try-catch para ler o arquivo
        try {
//Leia e formate a saída no console aqui:

            // Cabeçalho
            System.out.printf("%-4S %-15S %-7S %-5S %-15S %-15S %-15S \n", "id", "nome", "ano", "preço", "descricao", "diretor", "ator");
            while (entrada.hasNext()) {

                //Corpo

                int id = entrada.nextInt();
                String nome = entrada.next();
                Integer anoLancamento = entrada.nextInt();
                double preco = entrada.nextDouble();
                String descricao = entrada.next();
                String diretor = entrada.next();
                String nomeAtor = entrada.next();


                System.out.printf("%04d %-15S %-7S %5.1f %-15S %-15S %-15S \n", id,nome,anoLancamento,preco,descricao,diretor,nomeAtor);
            }
        } catch (NoSuchElementException erro) {
            System.out.println("Arquivo com problemas");
            deuRuim = true;
        } catch (IllegalStateException erro) {
            System.out.println("Erro na leitura do arquivo");
            deuRuim = true;
        } finally {
            entrada.close();
            try {
                arq.close();
            } catch (IOException erro) {
                System.out.println("Erro ao fechar o arquivo");
                deuRuim = true;
            }
            if (deuRuim) {
                System.exit(1);
            }
        }
    }

}
